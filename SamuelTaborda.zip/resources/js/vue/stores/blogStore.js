export default {
    namespaced: true,
    state: {
        blog_posts : [
            {
                attachments: {
                    link : '/images/Blog/1.jpg'
                },
                text : '#quedateEnCasa Fortalecer Relaciones Interpersonales',
                timestamp : 1588445039
            },
            {
                attachments: {
                    link : '/images/Blog/2.jpg'
                },
                text : '#quedateEnCasa Pasar tiempo en Cuarentena',
                timestamp : 1588445039
            },
            {
                attachments: {
                    link : '/images/Blog/3.jpg'
                },
                text : '#quedateEnCasa Actividades para tus hijos',
                timestamp : 1588445039
            },
            {
                attachments: {
                    link : '/images/Blog/4.jpg'
                },
                text : '#quedateEnCasa La Serenidad en Cuarentena',
                timestamp : 1588445039
            },
            {
                attachments: {
                    link : '/images/Blog/5.jpg'
                },
                text : '#quedateEnCasa ¿Cómo aprende el cerebro?',
                timestamp : 1588445039
            },
            {
                attachments: {
                    link : '/images/Blog/6.jpg'
                },
                text : '#quedateEnCasa Respetémos las diferencias',
                timestamp : 1588445039
            },
        ],
    },
    getters: {
    },
    mutations: {
      
    },
    actions: {
        getBlogPosts(){
            
        }
    }
}