<template>
    <div>
        <div class="title">
            Módulo en construcción...
        </div>
        <img src="/icons/undraw_towing_6yy4.svg" alt="site_under_construction" width="200">
    </div>
</template>