<template>
    <!-- Applause Button -->
    <div id="applause_button">
        
    </div>
    <!-- Applause Button -->
</template>