<template>
    <div>
        <img src="/images/Blog/3.jpg" alt="related_post">
        <div class="post_card_information">
            <div class="psot_card_title">
                Tema Relacionado
            </div>
        </div>
    </div>
</template>