<template>
    <div class="section container">
        <h1>Acerca de mí...</h1>
        <div class="description">
            PRESENTACION PSICOLOGO SAMUEL ALBERTO TABORDA RIOS <br><br>

            <div id="about_text">
                Psicólogo clínico por la universidad por la universidad Antonio Nariño, con formación en psicología infantil y juvenil, terapia del niño y la escuela, terapia de pareja de la universidad pontificia Bolivariana, donde tuve la oportunidad de prestar mis servicios como practicante de psicología en el colegio de la UPB, primaria y bachillerato, y posteriormente pase al centro de atención psicológica donde trabaje desde el año 2002 al 2010, cuando decidí retirarme para continuar en mi consultorio en el sector del poblado y laureles, durante esta época en el centro de atención tuve la oportunidad de atender al año entre 1450 y 1500 consultas clínicas con resultados muy positivos, así mismo estuve al frente de la atención en la emergencia del 2007 cuando una avioneta cayó en las instalaciones de la universidad con consecuencias psicológicas de ansiedad pánico y temor en estudiantes y empleados de la UPB, desde el año 2004 tuve la oportunidad de realizar programas de radio en la emisora de la universidad los cuales todavía realizo en directo con una periocidad de un programa mensual, y este espacio me permitió hacer mi primer programa en Telemedellín, Teleantioquia, y Cosmovisión, donde posteriormente tuve la oportunidad de estar en muchos programas en vivo, (Capicúa, las tres gracias, el diario de Diana Muy femenino, videos que hoy puedes observar en YouTube.
                También alterne mi servicio psicológico en la fundación multiimpedidos desde 2003 al 2009, donde atendía las familias de niños con múltiples discapacidades, manejando especialmente la negación y sobreprotección de un padre con un hijo con alguna discapacidad.
                Durante el tiempo que permanecí en la Fundación Multis, nombre actual, tuve la oportunidad de estar en un proyecto con la cuarta brigada atendiendo personal caído en batalla, donde el objetivo principal era RESIGNIFICAR SU PROYECTO DE VIDA y duelo por la pérdida de algún miembro de su cuerpo, atendí soldados con pérdida de miembros inferiores, superiores y muchos que por alguna razón perdieron su visión o la audición.
                Me desempeñe por espacio de 4 años como psicólogo asesor de la Arquidiócesis realizando los cursillos prematrimoniales a muchas parejas en la iglesia Nuestra Señora de Belén, en  el parque de Belén en la ciudad de Medellín.
                Desde el año 2010 llegue como conferencista en una escuela de padres al colegio Santa Bertilla Boscardín en el sector de Robledo, donde por intermedio de su rectora tuve la oportunidad de atender clínica a los estudiantes y familiares, así mismo estuve a cargo de la escuela de padres de familia con charlas mensuales y así por espacio de 10 años, cuando me voy a otra institución cercana llamada CORPORACION GUILLERMO TABORDA RESTREPO, donde actualmente apoyo en el área psicológica y de acompañamiento en escuela de padres.
                Desde el año 2016 pertenezco a la junta nacional de alcohólicos anónimos como custodio clase A (sin la enfermedad) apoyando la junta nacional y sirviendo de imagen en los medios de comunicación. También desde el año 2006 vengo prestando mi servicio clínico particular en un consultorio ubicado en el sector del estadio con un equipo interdisciplinario donde cuento con el apoyo de psiquiatras, psicólogos, neuropsicólogos, fonoaudiólogos, médicos
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>